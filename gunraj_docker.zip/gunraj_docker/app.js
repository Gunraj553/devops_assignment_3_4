const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
 
  res.send('My name is GUNRAJ SINGH SODHI and my id is C0893229');
});

app.use(bodyParser.json());

let employees = [];


class Employee {
    constructor(name, title, degrees, department, status, dateHired) {
        this.name = name;
        this.title = title;
        this.degrees = degrees;
        this.department = department;
        this.status = status;
        this.dateHired = dateHired;
    }
}


function findEmployeeIndex(name) {
    return employees.findIndex(emp => emp.name === name);
}




app.post('/addEmployee', (req, res) => {
    const { name } = req.body;

    
    if (findEmployeeIndex(name) !== -1) {
        return res.status(400).json({ error: 'Employee with that name already exists.' });
    }

    const newEmployee = new Employee(name, '', '', '', '', '');


    employees.push(newEmployee);

    res.status(200).json({ message: 'Employee added successfully.' });
});


app.get('/getEmployee/:name', (req, res) => {
    const name = req.params.name;
    const employee = employees.find(emp => emp.name === name);

    if (!employee) {
        return res.status(404).json({ error: 'Employee not found.' });
    }

    res.status(200).json(employee);
});

app.put('/updateEmployee/:name', (req, res) => {
    const name = req.params.name;
    const { status } = req.body;

    const index = findEmployeeIndex(name);

    if (index === -1) {
        return res.status(404).json({ error: 'Employee not found.' });
    }

    employees[index].status = status;
    res.status(200).json({ message: 'Employee status updated successfully.' });
});


app.get('/displayAllEmployees', (req, res) => {
    res.status(200).json(employees);
});



app.listen(port, () => {
  console.log(`App running on http://localhost:${port}`);
});
